package shared

type Operation string

const (
	Encrypt Operation = "encrypt"
	Decrypt Operation = "decrypt"
)

type Request struct {
	Message   string    `json:"message"`
	Operation Operation `json:"operation"`
}

type Response struct {
	OriginalMessage string `json:"originalMessage"`
	ResultMessage   string `json:"resultMessage"`
	Operation       string `json:"operation"`
}
