package main

import (
	"aes/shared"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
)

func main() {
	server := "localhost:8080"
	if envServer := os.Getenv("SERVER_ADDR"); envServer != "" {
		server = envServer
	}

	fmt.Println("=== AES Encryption-client ===")
	fmt.Println("Type '/quit' to exit the client")

	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Println("\nChoose an operation:")
		fmt.Println("1. Encryption")
		fmt.Println("2. Decryption")
		fmt.Print("> ")

		if !scanner.Scan() {
			break
		}
		choice := strings.TrimSpace(scanner.Text())

		if strings.ToLower(choice) == "/quit" {
			break
		}

		var operation shared.Operation
		switch choice {
		case "1":
			operation = shared.Encrypt
			fmt.Println("Encryption mode")
		case "2":
			operation = shared.Decrypt
			fmt.Println("Decryption mode")
		default:
			fmt.Println("Invalid choice, please choose 1 or 2")
			continue
		}

		fmt.Print("Enter a message: ")
		if !scanner.Scan() {
			break
		}
		message := strings.TrimSpace(scanner.Text())

		if strings.ToLower(message) == "/quit" {
			break
		}

		req := shared.Request{
			Message:   message,
			Operation: operation,
		}

		resp, err := sendRequest(server, req)
		if err != nil {
			fmt.Printf("Error in request: %v\n", err)
			continue
		}

		fmt.Println("\n=== Server response ===")
		fmt.Printf("Original message: %s\n", resp.OriginalMessage)
		fmt.Printf("%s to: %s\n", resp.Operation, resp.ResultMessage)
		fmt.Println("=====================")
	}

	fmt.Println("Client is closing.")
}

func sendRequest(server string, req shared.Request) (*shared.Response, error) {
	jsonData, err := json.Marshal(req)
	if err != nil {
		return nil, fmt.Errorf("error in json marshalling: %v", err)
	}

	resp, err := http.Post(
		fmt.Sprintf("http://%s/crypto", server),
		"application/json",
		bytes.NewBuffer(jsonData),
	)
	if err != nil {
		return nil, fmt.Errorf("error sending the request: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("server error (Status %d): %s", resp.StatusCode, string(bodyBytes))
	}

	bodyBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("error reading the response: %v", err)
	}

	var response shared.Response
	if err := json.Unmarshal(bodyBytes, &response); err != nil {
		return nil, fmt.Errorf("error in json unmarshalling: %v", err)
	}

	return &response, nil
}
