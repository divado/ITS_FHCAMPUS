package main

import (
	"bufio"
	"ec/shared"
	"encoding/json"
	"fmt"
	"log"
	"math/big"
	"net"
	"os"
	"sync"
)

func main() {
	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}

	log.Printf("EC-Server started on port %s...", port)
	listener, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("Error starting the server: %v", err)
	}
	defer listener.Close()

	var wg sync.WaitGroup
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Error accepting connection: %v", err)
			continue
		}

		wg.Add(1)
		go handleConnection(conn, &wg)
	}
}

func handleConnection(conn net.Conn, wg *sync.WaitGroup) {
	defer wg.Done()
	defer conn.Close()

	log.Printf("New connection from: %s", conn.RemoteAddr())

	scanner := bufio.NewScanner(conn)
	for scanner.Scan() {
		requestData := scanner.Text()
		log.Printf("Received request: %s", requestData)

		var request shared.ScalarMultRequest
		if err := json.Unmarshal([]byte(requestData), &request); err != nil {
			sendErrorResponse(conn, fmt.Errorf("Invalid request format: %v", err))
			continue
		}

		response := processScalarMult(request)

		responseJSON, err := json.Marshal(response)
		if err != nil {
			log.Printf("Error serializing the response: %v", err)
			continue
		}

		if _, err := fmt.Fprintln(conn, string(responseJSON)); err != nil {
			log.Printf("Error sending the response: %v", err)
			return
		}
	}

	if err := scanner.Err(); err != nil {
		log.Printf("Error reading from connection: %v", err)
	}
}

func processScalarMult(req shared.ScalarMultRequest) shared.ScalarMultResponse {
	p, a, b, _, err := shared.CurveParamsToBigInt(req.Curve)
	if err != nil {
		return shared.ErrorResponse(err)
	}

	x, y, err := shared.PointToBigInt(req.Point)
	if err != nil {
		return shared.ErrorResponse(err)
	}

	if !shared.IsOnCurve(x, y, a, b, p) {
		return shared.ErrorResponse(shared.ErrPointNotOnCurve)
	}

	k, success := new(big.Int).SetString(req.Scalar, 10)
	if !success {
		return shared.ErrorResponse(shared.ErrInvalidScalar)
	}

	resultX, resultY := scalarMultiplication(x, y, k, a, b, p)

	isInfinity := resultX == nil || resultY == nil ||
		(resultX.Sign() == 0 && resultY.Sign() == 0)

	if isInfinity {
		return shared.ScalarMultResponse{
			Point:      shared.Point{X: "0", Y: "0"},
			IsInfinity: true,
		}
	}

	return shared.ScalarMultResponse{
		Point:      shared.BigIntToPoint(resultX, resultY),
		IsInfinity: false,
	}
}

func sendErrorResponse(conn net.Conn, err error) {
	response := shared.ErrorResponse(err)
	responseJSON, _ := json.Marshal(response)
	fmt.Fprintln(conn, string(responseJSON))
}

func scalarMultiplication(x, y, k, a, b, p *big.Int) (*big.Int, *big.Int) {
	if k.Sign() == 0 {
		return big.NewInt(0), big.NewInt(0)
	}

	kCopy := new(big.Int).Set(k)

	isNegative := kCopy.Sign() < 0
	if isNegative {
		kCopy.Neg(kCopy)
	}

	var resultX, resultY *big.Int = nil, nil

	tempX, tempY := new(big.Int).Set(x), new(big.Int).Set(y)

	for kCopy.BitLen() > 0 {
		if kCopy.Bit(0) == 1 {
			resultX, resultY = pointAddition(resultX, resultY, tempX, tempY, a, b, p)
		}

		tempX, tempY = pointDoubling(tempX, tempY, a, b, p)

		kCopy.Rsh(kCopy, 1)
	}

	if isNegative && resultY != nil {
		resultY.Neg(resultY)
		resultY.Mod(resultY, p)
	}

	return resultX, resultY
}

func pointAddition(x1, y1, x2, y2, a, b, p *big.Int) (*big.Int, *big.Int) {
	if x1 == nil || y1 == nil {
		if x2 == nil || y2 == nil {
			return nil, nil
		}
		return new(big.Int).Set(x2), new(big.Int).Set(y2)
	}

	if x2 == nil || y2 == nil {
		return new(big.Int).Set(x1), new(big.Int).Set(y1)
	}

	if x1.Cmp(x2) == 0 && y1.Cmp(y2) == 0 {
		return pointDoubling(x1, y1, a, b, p)
	}

	negY2 := new(big.Int).Neg(y2)
	negY2.Mod(negY2, p)
	if x1.Cmp(x2) == 0 && y1.Cmp(negY2) == 0 {
		return big.NewInt(0), big.NewInt(0)
	}

	numerator := new(big.Int).Sub(y2, y1)
	numerator.Mod(numerator, p)

	denominator := new(big.Int).Sub(x2, x1)
	denominator.Mod(denominator, p)
	denominatorInv := new(big.Int).ModInverse(denominator, p)

	s := new(big.Int).Mul(numerator, denominatorInv)
	s.Mod(s, p)

	x3 := new(big.Int).Mul(s, s)
	x3.Sub(x3, x1)
	x3.Sub(x3, x2)
	x3.Mod(x3, p)

	y3 := new(big.Int).Sub(x1, x3)
	y3.Mul(y3, s)
	y3.Sub(y3, y1)
	y3.Mod(y3, p)

	return x3, y3
}

func pointDoubling(x, y, a, b, p *big.Int) (*big.Int, *big.Int) {
	if x == nil || y == nil || (x.Sign() == 0 && y.Sign() == 0) {
		return nil, nil
	}

	if y.Sign() == 0 {
		return big.NewInt(0), big.NewInt(0)
	}

	xSquared := new(big.Int).Mul(x, x)
	xSquared.Mod(xSquared, p)

	numerator := new(big.Int).Mul(big.NewInt(3), xSquared)
	numerator.Add(numerator, a)
	numerator.Mod(numerator, p)

	denominator := new(big.Int).Mul(big.NewInt(2), y)
	denominator.Mod(denominator, p)
	denominatorInv := new(big.Int).ModInverse(denominator, p)

	s := new(big.Int).Mul(numerator, denominatorInv)
	s.Mod(s, p)

	x3 := new(big.Int).Mul(s, s)
	twoX := new(big.Int).Mul(big.NewInt(2), x)
	x3.Sub(x3, twoX)
	x3.Mod(x3, p)

	y3 := new(big.Int).Sub(x, x3)
	y3.Mul(y3, s)
	y3.Sub(y3, y)
	y3.Mod(y3, p)

	return x3, y3
}
