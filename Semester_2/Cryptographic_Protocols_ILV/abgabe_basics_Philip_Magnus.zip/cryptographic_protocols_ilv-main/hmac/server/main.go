package main

import (
	"bufio"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"log"
	"net"
	"os"
	"strings"
)

const (
	secretKey = "SecretKey"
)

func main() {

	serverAddr := "localhost:8080"
	if envServerPort := os.Getenv("SERVER_PORT"); envServerPort != "" {
		serverAddr = ":" + envServerPort
	}

	listener, err := net.Listen("tcp", serverAddr)
	if err != nil {
		log.Fatalln("ERROR STARTING SERVER:", err)
		os.Exit(1)
	}
	defer listener.Close()

	log.Println("SERVER STARTED ON:", serverAddr)

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Println("ERROR ACCEPTING CONNECTION:", err)
			continue
		}

		go handleConnection(conn)
	}
}

func handleConnection(conn net.Conn) {
	defer conn.Close()
	log.Println("NEW CONNECTION FROM:", conn.RemoteAddr())

	reader := bufio.NewReader(conn)

	message, err := reader.ReadString('\n')
	if err != nil {
		log.Println("ERROR READING MESSAGE:", err)
		return
	}

	parts := strings.Split(strings.TrimSpace(message), ":")
	if len(parts) != 2 {
		log.Println("INVALID MESSAGE FORMAT.")
		return
	}

	receivedMsg := parts[0]
	receivedMAC := parts[1]

	log.Printf("RECEIVED MESSAGE: %s, HMAC: %s\n", receivedMsg, receivedMAC)

	h := hmac.New(sha256.New, []byte(secretKey))
	h.Write([]byte(receivedMsg))
	expectedMAC := hex.EncodeToString(h.Sum(nil))

	if hmac.Equal([]byte(receivedMAC), []byte(expectedMAC)) {
		response := "Message authenticated: " + receivedMsg
		log.Println(response)
		conn.Write([]byte(response + "\n"))
	} else {
		response := "HMAC invalid! Message may be manipulated."
		log.Println(response)
		conn.Write([]byte(response + "\n"))
	}
}
