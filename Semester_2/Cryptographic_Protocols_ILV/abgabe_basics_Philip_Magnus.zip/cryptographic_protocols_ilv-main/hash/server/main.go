package main

import (
	"crypto/sha512"
	"encoding/base64"
	"encoding/json"
	"hash/shared"
	"io"
	"log"
	"net/http"
	"os"
)

func main() {
	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}

	http.HandleFunc("/hash", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
			return
		}
		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Failed to read request body", http.StatusBadRequest)
			return
		}
		defer r.Body.Close()

		req := &shared.Request{}
		err = json.Unmarshal(body, req)
		if err != nil {
			http.Error(w, "Failed to unmarshal request", http.StatusBadRequest)
			return
		}

		log.Printf("RECEIVED MESSAGE: %s\n", req.Message)

		hasher := sha512.New()
		hasher.Write([]byte(req.Message))
		hash := base64.StdEncoding.EncodeToString(hasher.Sum(nil))

		resp := shared.Response{
			Message: req.Message,
			Hash:    string(hash),
		}

		marshaled, err := json.Marshal(resp)
		if err != nil {
			http.Error(w, "Failed to marshal response", http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write(marshaled)
	})

	log.Println("Server is listening on port", port)
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
