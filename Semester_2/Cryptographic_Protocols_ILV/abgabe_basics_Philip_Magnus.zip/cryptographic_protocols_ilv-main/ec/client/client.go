package main

import (
	"bufio"
	"crypto/rand"
	"ec/shared"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/big"
	"net"
	"os"
)

// Standard parameter for curve P-256
var defaultCurveParams = shared.CurveParams{
	P: "115792089210356248762697446949407573530086143415290314195533631308867097853951",
	A: "-3",
	B: "41058363725152142129326129780047268409114441015993725554835256314039467401291",
	N: "115792089210356248762697446949407573529996955224135760342422259061068512044369",
}

// Standard base point for P-256
var defaultBasePoint = shared.Point{
	X: "91540914135043588623749714839822523547524574078143366117280151371884244429695",
	Y: "24745949808152764940887807086314913015834445242598033900711468967165968436455",
}

func main() {
	serverAddr := flag.String("server", "", "Address of EC-server (Host:Port)")
	randomize := flag.Bool("random-scalar", false, "Use Random Scalar")
	useCustomPoint := flag.Bool("custom-point", false, "Use a user defined point")
	useRandomPoint := flag.Bool("random-point", false, "Use a random point on the curve")
	useRandomCurve := flag.Bool("random-curve", false, "Use random curve parameters")
	scalarStr := flag.String("scalar", "811935", "Use a specified scalar (if -random is not set)")
	help := flag.Bool("help", false, "display help message")
	flag.Parse()

	if *help {
		fmt.Println("Usage: ec-client [options]")
		fmt.Println("Options:")
		flag.PrintDefaults()
		return
	}

	serverAddrStr := *serverAddr
	if serverAddrStr == "" {

		if envAddr := os.Getenv("SERVER_ADDR"); envAddr != "" {
			serverAddrStr = envAddr
		} else {
			serverAddrStr = "localhost:8080"
		}
	}

	conn, err := net.Dial("tcp", serverAddrStr)
	if err != nil {
		log.Fatalf("Connection to server failed: %v", err)
	}
	defer conn.Close()

	var curve shared.CurveParams
	if *useRandomCurve {
		curve = generateRandomCurve()
		log.Printf("Generated random curve parameters: p=%s, a=%s, b=%s",
			curve.P, curve.A, curve.B)
	} else {
		curve = defaultCurveParams
	}

	p, a, b, n, err := shared.CurveParamsToBigInt(curve)
	if err != nil {
		log.Fatalf("Invalid curve parameters: %v", err)
	}

	var point shared.Point
	if *useRandomPoint {
		point = generateRandomPoint(p, a, b)
		log.Printf("Generated random point: (%s, %s)", point.X, point.Y)
	} else if *useCustomPoint {
		point = readCustomPoint()
	} else {
		point = defaultBasePoint
	}

	var scalar string
	if *randomize && !*useRandomCurve {
		k, err := rand.Int(rand.Reader, new(big.Int).Sub(n, big.NewInt(1)))
		if err != nil {
			log.Fatalf("Error generating a random scalar: %v", err)
		}
		k.Add(k, big.NewInt(1))
		scalar = k.String()
		log.Printf("Generated random scalar: %s", scalar)
	} else {
		scalar = *scalarStr
	}

	request := shared.ScalarMultRequest{
		Curve:  curve,
		Point:  point,
		Scalar: scalar,
	}

	requestJSON, err := json.Marshal(request)
	if err != nil {
		log.Fatalf("Error serializing the request: %v", err)
	}

	if _, err := fmt.Fprintln(conn, string(requestJSON)); err != nil {
		log.Fatalf("Error sending the request: %v", err)
	}

	log.Println("Request sent, waiting for response...")

	scanner := bufio.NewScanner(conn)
	if scanner.Scan() {
		responseData := scanner.Text()
		var response shared.ScalarMultResponse

		if err := json.Unmarshal([]byte(responseData), &response); err != nil {
			log.Fatalf("Error parsing the response: %v", err)
		}

		// Überprüfen, ob ein Fehler aufgetreten ist
		if response.Error != "" {
			log.Fatalf("Internal server error: %s", response.Error)
		}

		log.Println("Received response:")

		if response.IsInfinity {
			log.Println("Result: Point is at infinity (O)")
		} else {
			log.Printf("Result: (%s, %s)", response.Point.X, response.Point.Y)

			x, y, err := shared.PointToBigInt(response.Point)
			if err != nil {
				log.Fatalf("Invalid point in response: %v", err)
			}

			if shared.IsOnCurve(x, y, a, b, p) {
				log.Println("Verification: point is on the curve ✓")
			} else {
				log.Println("Verification: point is not on the curve ✗")
			}
		}
	} else {
		log.Fatalf("Error receiving the response: %v", scanner.Err())
	}
}

func generateRandomCurve() shared.CurveParams {
	pBits := 256
	p, err := rand.Prime(rand.Reader, pBits)
	if err != nil {
		log.Fatalf("Error generating a prime number: %v", err)
	}

	aMax := new(big.Int).SetUint64(100)
	a, err := rand.Int(rand.Reader, aMax)
	if err != nil {
		log.Fatalf("Error generating coefficient of a: %v", err)
	}

	if randBit() {
		a.Neg(a)
	}

	bMax := new(big.Int).SetUint64(100)
	b, err := rand.Int(rand.Reader, bMax)
	if err != nil {
		log.Fatalf("Error generating coefficient of b: %v", err)
	}
	if b.Sign() == 0 {
		b.SetUint64(1)
	}

	return shared.CurveParams{
		P: p.String(),
		A: a.String(),
		B: b.String(),
		// N left empty, not calculated
	}
}

func generateRandomPoint(p, a, b *big.Int) shared.Point {
	for {
		x, err := rand.Int(rand.Reader, p)
		if err != nil {
			log.Fatalf("Error generating a random value x: %v", err)
		}

		xCube := new(big.Int).Exp(x, big.NewInt(3), p)
		ax := new(big.Int).Mul(a, x)
		ax.Mod(ax, p)

		ySq := new(big.Int).Add(xCube, ax)
		ySq.Add(ySq, b)
		ySq.Mod(ySq, p)
		y := new(big.Int).ModSqrt(ySq, p)
		if y != nil {
			if randBit() {
				y.Sub(p, y)
				y.Mod(y, p)
			}

			return shared.Point{
				X: x.String(),
				Y: y.String(),
			}
		}
	}
}

func readCustomPoint() shared.Point {
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Please enter the X coordinate of your point: ")
	xStr, _ := reader.ReadString('\n')
	xStr = xStr[:len(xStr)-1]

	fmt.Print("Please enter the Y coordinate of your point: ")
	yStr, _ := reader.ReadString('\n')
	yStr = yStr[:len(yStr)-1]

	return shared.Point{
		X: xStr,
		Y: yStr,
	}
}

func randBit() bool {
	b := make([]byte, 1)
	rand.Read(b)
	return b[0]&1 == 1
}
