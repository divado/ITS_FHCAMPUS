package main

import (
	"bufio"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"strings"
)

const (
	secretKey = "SecretKey"
)

func main() {

	serverAddr := "localhost:8080"
	if envServerAddr := os.Getenv("SERVER_ADDR"); envServerAddr != "" {
		serverAddr = envServerAddr
	}

	conn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		fmt.Println("ERROR CONNECTING TO SERVER:", err)
		os.Exit(1)
	}
	defer conn.Close()

	fmt.Println("CONNECTED TO SERVER:", serverAddr)

	reader := bufio.NewReader(os.Stdin)
	fmt.Print("PLEASE ENTER A MESSAGE > ")
	message, _ := reader.ReadString('\n')
	message = strings.TrimSpace(message)

	h := hmac.New(sha256.New, []byte(secretKey))
	h.Write([]byte(message))
	messageMAC := hex.EncodeToString(h.Sum(nil))

	fmt.Fprintf(conn, "%s:%s\n", message, messageMAC)
	fmt.Printf("SEND MESSAGE: %s, HMAC:%s\n", message, messageMAC)

	response, err := bufio.NewReader(conn).ReadString('\n')
	if err != nil {
		fmt.Println("ERROR READING RESPONSE:", err)
		return
	}

	fmt.Println("RESPONSE FROM SERVER:", strings.TrimSpace(response))
}
