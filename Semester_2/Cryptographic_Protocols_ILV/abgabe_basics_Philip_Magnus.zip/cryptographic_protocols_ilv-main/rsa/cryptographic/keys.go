package cryptographic

import (
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"math/big"
	"os"
)

// RSAKeyPair holds the public and private keys
type RSAKeyPair struct {
	PublicKey  *RSAPublicKey
	PrivateKey *RSAPrivateKey
}

// RSAPublicKey holds the public key components
// N is the modulus
// E is the public exponent
type RSAPublicKey struct {
	N *big.Int
	E *big.Int
}

// RSAPrivateKey holds the private key components
// N is the modulus
// D is the private exponent
type RSAPrivateKey struct {
	N *big.Int
	D *big.Int
}

func (pub *RSAPublicKey) ToPEM() ([]byte, error) {
	pubKey := &rsa.PublicKey{
		N: pub.N,
		E: int(pub.E.Int64()),
	}

	derBytes, err := x509.MarshalPKIXPublicKey(pubKey)
	if err != nil {
		return nil, err
	}

	pemBlock := &pem.Block{
		Type:  "RSA PUBLIC KEY",
		Bytes: derBytes,
	}

	return pem.EncodeToMemory(pemBlock), nil
}

func (priv *RSAPrivateKey) ToPEM(p, q *big.Int) ([]byte, error) {
	privKey := &rsa.PrivateKey{
		PublicKey: rsa.PublicKey{
			N: priv.N,
			E: 65537,
		},
		D:      priv.D,
		Primes: []*big.Int{p, q},
	}

	// Marshal to DER format
	derBytes, err := x509.MarshalPKCS8PrivateKey(privKey)
	if err != nil {
		return nil, err
	}

	// Create PEM block
	pemBlock := &pem.Block{
		Type:  "RSA PRIVATE KEY",
		Bytes: derBytes,
	}

	return pem.EncodeToMemory(pemBlock), nil
}

func ParseRSAPublicKeyFromPEM(pemBytes []byte) (*RSAPublicKey, error) {
	block, _ := pem.Decode(pemBytes)
	if block == nil {
		return nil, fmt.Errorf("failed to decode PEM block")
	}

	pubKey, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, fmt.Errorf("failed to parse DER encoded public key: %v", err)
	}

	rsaPubKey, ok := pubKey.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("not an RSA public key")
	}

	return &RSAPublicKey{
		N: rsaPubKey.N,
		E: big.NewInt(int64(rsaPubKey.E)),
	}, nil
}

func SavePEMToFile(filename string, pemBytes []byte) error {
	file, err := os.Create(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	_, err = file.Write(pemBytes)
	return err
}

func GenerateKeyPair(bits int) (*RSAKeyPair, *big.Int, *big.Int, error) {
	p, err := GeneratePrime(bits / 2)
	if err != nil {
		return nil, nil, nil, err
	}

	q, err := GeneratePrime(bits / 2)
	if err != nil {
		return nil, nil, nil, err
	}

	n := new(big.Int).Mul(p, q)

	pMinus1 := new(big.Int).Sub(p, big.NewInt(1))
	qMinus1 := new(big.Int).Sub(q, big.NewInt(1))
	totient := new(big.Int).Mul(pMinus1, qMinus1)

	e := big.NewInt(65537)

	d, err := ModInverse(e, totient)
	if err != nil {
		return nil, nil, nil, err
	}

	return &RSAKeyPair{
		PublicKey: &RSAPublicKey{
			N: n,
			E: e,
		},
		PrivateKey: &RSAPrivateKey{
			N: n,
			D: d,
		},
	}, p, q, nil
}
