package main

import (
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"net/http"
	"os"
	"x509App/shared"
)

func main() {

	server := "localhost:8080"
	if envServer := os.Getenv("SERVER_ADDR"); envServer != "" {
		server = envServer
	}

	resp, err := http.Get("http://" + server + "/certificate")
	if err != nil {
		fmt.Println("Error fetching certificate:", err)
		return
	}
	defer resp.Body.Close()

	certPEM, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Error reading response body:", err)
		return
	}

	block, rest := pem.Decode(certPEM)
	if block == nil {
		fmt.Println("Failed to parse certificate PEM")
		if len(rest) > 0 {
			fmt.Printf("Remaining data (first 50 bytes): %s\n", string(rest[:min(50, len(rest))]))
		}
		return
	}

	fmt.Printf("PEM block type: %s\n", block.Type)

	cert, err := x509.ParseCertificate(block.Bytes)
	if err != nil {
		fmt.Println("Error parsing certificate:", err)
		return
	}

	fmt.Println("Certificate fetched successfully:")
	fmt.Printf("Subject: %s\n", cert.Subject)
	fmt.Printf("Issuer: %s\n", cert.Issuer)
	fmt.Printf("Not Before: %s\n", cert.NotBefore)
	fmt.Printf("Not After: %s\n", cert.NotAfter)

	fmt.Printf("Certificate vaildity: %s\n", shared.ValidateCertificate(cert))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
