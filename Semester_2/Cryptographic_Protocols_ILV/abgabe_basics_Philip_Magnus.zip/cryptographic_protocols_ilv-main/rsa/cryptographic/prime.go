package cryptographic

import (
	"crypto/rand"
	"fmt"
	"math/big"
)

func GeneratePrime(bits int) (*big.Int, error) {
	p, err := rand.Prime(rand.Reader, bits)
	if err != nil {
		return nil, err
	}
	return p, nil
}

func ExtendedGCD(a, b *big.Int) (*big.Int, *big.Int, *big.Int) {
	if b.Cmp(big.NewInt(0)) == 0 {
		return a, big.NewInt(1), big.NewInt(0)
	}

	gcd, x1, y1 := ExtendedGCD(b, new(big.Int).Mod(a, b))
	y := new(big.Int).Sub(x1, new(big.Int).Mul(new(big.Int).Div(a, b), y1))
	return gcd, y1, y
}

func ModInverse(a, m *big.Int) (*big.Int, error) {
	gcd, x, _ := ExtendedGCD(a, m)
	if gcd.Cmp(big.NewInt(1)) != 0 {
		return nil, fmt.Errorf("no modular inverse exists")
	}
	return x.Mod(x, m), nil
}
