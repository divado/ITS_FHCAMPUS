package main

import (
	"bufio"
	"crypto-prot/cryptographic"
	"crypto/rsa"
	"encoding/base64"
	"fmt"
	"log"
	"math/big"
	"net"
	"os"
	"strings"
)

var (
	encryptionEnabled bool
	serverPubKey      *cryptographic.RSAPublicKey
	clientKeyPair     *cryptographic.RSAKeyPair
)

func genClientKeys() error {
	var err error
	var p, q *big.Int

	clientKeyPair, p, q, err = cryptographic.GenerateKeyPair(2048)

	// Convert and save public key
	pubPEM, err := clientKeyPair.PublicKey.ToPEM()
	if err != nil {
		fmt.Println("Error encoding public key:", err)
		return err
	}
	err = cryptographic.SavePEMToFile("server_public.pem", pubPEM)
	if err != nil {
		fmt.Println("Error saving public key:", err)
		return err
	}

	// Convert and save private key
	privPEM, err := clientKeyPair.PrivateKey.ToPEM(p, q)
	if err != nil {
		fmt.Println("Error encoding private key:", err)
		return err
	}
	err = cryptographic.SavePEMToFile("server_private.pem", privPEM)
	if err != nil {
		fmt.Println("Error saving private key:", err)
		return err
	}

	return nil
}

func sendPublickey(conn net.Conn) error {
	// pubKey := &rsa.PublicKey{
	// 	N: clientKeyPair.PublicKey.N,
	// 	E: int(clientKeyPair.PublicKey.E.Int64()),
	// }

	// pemBlock := &pem.Block{
	// 	Type:  "RSA PUBLIC KEY",
	// 	Bytes: x509.MarshalPKCS1PublicKey(pubKey),
	// }

	pubPEM, err := clientKeyPair.PublicKey.ToPEM()
	if err != nil {
		log.Printf("Error encoding public key: %v", err)
	}

	encodedKey := base64.StdEncoding.EncodeToString(pubPEM)
	_, err = fmt.Fprintf(conn, "PUBLIC_KEY:%s\n", encodedKey)
	return err
}

func requestServerPubKey(conn net.Conn) {
	fmt.Fprintf(conn, "GET_PUBLIC_KEY\n")
}

func handleEncryptedMessage(message string) string {
	if strings.HasPrefix(message, "PUBLIC_KEY:") {
		encodedKey := strings.TrimPrefix(message, "PUBLIC_KEY:")
		decodedKey, err := base64.StdEncoding.DecodeString(encodedKey)
		if err != nil {
			log.Printf("Error decoding public key form server: %v", err)
			return "ERROR: invalid key format"
		}

		sPK, err := cryptographic.ParseRSAPublicKeyFromPEM(decodedKey)
		if err != nil {
			log.Printf("Error parsing public key form server: %v", err)
			return "ERROR: invalid public key"
		}

		serverPubKey = sPK
		return "SUCCESS: Server public key received"
	} else if strings.HasPrefix(message, "ENC:") {
		encryptedMsg := strings.TrimPrefix(message, "ENC:")
		decodedMsg, err := base64.StdEncoding.DecodeString(encryptedMsg)
		if err != nil {
			log.Printf("Error decoding encrypted message: %v", err)
			return "ERROR: invalid encrypted message"
		}
		decryptedMsg, err := cryptographic.Decrypt(decodedMsg, clientKeyPair.PrivateKey)
		if err != nil {
			log.Printf("Error decrypting message: %v", err)
			return ""
		}
		return string(decryptedMsg)

	}
	return message
}

func extractKey(key *rsa.PublicKey) *cryptographic.RSAPublicKey {
	return &cryptographic.RSAPublicKey{
		N: key.N,
		E: big.NewInt(int64(key.E)),
	}
}

func printEncryptionCommands() {
	fmt.Println("\nAvailable encryption commands:")
	fmt.Println("/encrpyt - Toggle encryption mode (current: " + fmt.Sprintf("%v", encryptionEnabled) + ")")
	fmt.Println("/setup - Setup encryption (generates keys and exchanges these with the server)")
	fmt.Println("/status - Show current encryption status")
}

func printWIthPrompt(msg string, rawMsg string) {
	fmt.Printf("Raw message from Server: %s\n", rawMsg)
	fmt.Println(msg)
	fmt.Printf("> ")
}

func main() {
	serverAddr := "localhost:8080"
	if envServerAddr := os.Getenv("SERVER_ADDR"); envServerAddr != "" {
		serverAddr = envServerAddr
	}

	if err := genClientKeys(); err != nil {
		log.Fatalf("Error generating client keys: %v", err)
	}

	conn, err := net.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatalf("Error connecting to server: %v", err)
	}
	defer conn.Close()

	encryptionEnabled = false

	fmt.Println("Connected to server", serverAddr)

	serverMsgs := make(chan string)
	clientInput := make(chan string)
	done := make(chan struct{})

	go func() {
		scanner := bufio.NewScanner(conn)
		for scanner.Scan() {
			serverMsgs <- scanner.Text()
		}
		if err := scanner.Err(); err != nil {
			log.Printf("Error reading from server: %v", err)
		}
		close(done)
	}()

	go func() {
		scanner := bufio.NewScanner(os.Stdin)
		fmt.Printf("> ")
		for scanner.Scan() {
			clientInput <- scanner.Text()
		}
		if err := scanner.Err(); err != nil {
			log.Printf("Error reading from stdin: %v", err)
		}
	}()

	for {
		select {
		case msg := <-serverMsgs:
			processedMsg := handleEncryptedMessage(msg)
			printWIthPrompt("Server: "+processedMsg, msg)

		case input := <-clientInput:
			if strings.HasPrefix(input, "/") {
				command := strings.ToLower(input)
				switch command {
				case "/help":
					printEncryptionCommands()
					fmt.Printf("> ")
					continue
				case "/setup":
					requestServerPubKey(conn)
					if err := sendPublickey(conn); err != nil {
						log.Printf("Error sending public key: %v", err)
					}
					continue
				case "/encrypt":
					encryptionEnabled = !encryptionEnabled
					fmt.Println("Encryption mode set to:", encryptionEnabled)
					fmt.Printf("> ")
					continue
				case "/status":
					fmt.Println("Encryption enabled:", encryptionEnabled)
					fmt.Println("Server public key available:", serverPubKey != nil)
					fmt.Printf("> ")
					continue
				case "/quit":
					fmt.Fprintf(conn, "%s\n", input)
					fmt.Println("Disconnecting from server...")
					return
				}
			}

			if encryptionEnabled && serverPubKey != nil {
				encryptedMsg, err := cryptographic.Encrypt([]byte(input), serverPubKey)
				if err != nil {
					fmt.Println("Error encrypting message:", err)
					continue
				}
				fmt.Fprintf(conn, "ENC:%s\n", base64.StdEncoding.EncodeToString(encryptedMsg))
			} else {
				fmt.Fprintf(conn, "%s\n", input)
			}

		case <-done:
			fmt.Println("Connection closed by server")
			return
		}
	}
}
