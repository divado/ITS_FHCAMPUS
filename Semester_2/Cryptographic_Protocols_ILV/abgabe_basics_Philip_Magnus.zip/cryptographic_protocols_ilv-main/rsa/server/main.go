package main

import (
	"bufio"
	"crypto-prot/cryptographic"
	"encoding/base64"
	"fmt"
	"log"
	"math/big"
	"net"
	"os"
	"strings"
	"time"
)

var (
	serverKeyPair    *cryptographic.RSAKeyPair
	clientPublicKeys = make(map[string]*cryptographic.RSAPublicKey)
)

func genServerKeys() error {
	var err error
	var p, q *big.Int

	serverKeyPair, p, q, err = cryptographic.GenerateKeyPair(2048)

	// Convert and save public key
	pubPEM, err := serverKeyPair.PublicKey.ToPEM()
	if err != nil {
		fmt.Println("Error encoding public key:", err)
		return err
	}
	err = cryptographic.SavePEMToFile("server_public.pem", pubPEM)
	if err != nil {
		fmt.Println("Error saving public key:", err)
		return err
	}

	// Convert and save private key
	privPEM, err := serverKeyPair.PrivateKey.ToPEM(p, q)
	if err != nil {
		fmt.Println("Error encoding private key:", err)
		return err
	}
	err = cryptographic.SavePEMToFile("server_private.pem", privPEM)
	if err != nil {
		fmt.Println("Error saving private key:", err)
		return err
	}

	return nil
}

func handleEncryptionMessages(conn net.Conn, clientAddr string, message string) bool {
	if strings.HasPrefix(message, "PUBLIC_KEY:") {
		encodedKey := strings.TrimPrefix(message, "PUBLIC_KEY:")
		decodedKey, err := base64.StdEncoding.DecodeString(encodedKey)
		if err != nil {
			log.Printf("Error decoding client public key: %v", err)
			fmt.Fprintf(conn, "ERROR: Invalid public key format\n")
			return true
		}

		clientPublicKey, err := cryptographic.ParseRSAPublicKeyFromPEM(decodedKey)
		if err != nil {
			log.Printf("Error parsing client public key: %v", err)
			return true
		}

		clientPublicKeys[clientAddr] = clientPublicKey
		log.Printf("Received public key from client: %s", clientAddr)
		return true

	} else if message == "GET_PUBLIC_KEY" {
		pubPEM, err := serverKeyPair.PublicKey.ToPEM()
		if err != nil {
			log.Printf("Error encoding public key: %v", err)
		}

		encodedKey := base64.StdEncoding.EncodeToString(pubPEM)
		fmt.Fprintf(conn, "PUBLIC_KEY:%s\n", encodedKey)
		return true
	} else if strings.HasPrefix(message, "ENC:") {
		encryptedMsg := strings.TrimPrefix(message, "ENC:")
		decodedMsg, err := base64.StdEncoding.DecodeString(encryptedMsg)
		if err != nil {
			log.Printf("Error decoding encrypted message from %s: %v", clientAddr, err)
			return true
		}
		decryptedMsg, err := cryptographic.Decrypt(decodedMsg, serverKeyPair.PrivateKey)
		if err != nil {
			log.Printf("Error decrypting message from %s: %v", clientAddr, err)
			return true
		}

		log.Printf("Decrypted message from %s: %s", clientAddr, decryptedMsg)

		if clientKey, ok := clientPublicKeys[clientAddr]; ok {
			response := fmt.Sprintf("[%s] Server received: %s\n",
				time.Now().Format(time.RFC3339), decryptedMsg)
			encryptedResponse, err := cryptographic.Encrypt([]byte(response), clientKey)
			if err != nil {
				log.Printf("Error encrypting response for %s: %v", clientAddr, err)
			} else {
				fmt.Fprintf(conn, "ENC:%s\n", base64.StdEncoding.EncodeToString(encryptedResponse))
			}
		} else {
			log.Printf("No public key found for client: %s", clientAddr)
		}
		return true

	}
	return false
}

func handleConnection(conn net.Conn) {
	defer conn.Close()

	// Client address info for logging
	clientAddr := conn.RemoteAddr().String()
	log.Printf("Client connected: %s", clientAddr)

	// Set a deadline for the connection
	conn.SetDeadline(time.Now().Add(5 * time.Minute))

	// Create a scanner to read client messages
	scanner := bufio.NewScanner(conn)

	// Greeting
	fmt.Fprintf(conn, "Welcome to the Go server! Type '/quit' to exit.\n")

	for scanner.Scan() {
		// Read message from client
		message := scanner.Text()
		log.Printf("Raw message from %s: %s", clientAddr, message)

		// Check if client wants to quit
		if strings.ToLower(message) == "/quit" {
			fmt.Fprintf(conn, "Goodbye!\n")
			break
		}

		if handleEncryptionMessages(conn, clientAddr, message) {
			conn.SetDeadline(time.Now().Add(5 * time.Minute))
			continue
		}

		// Echo the message back with a timestamp
		response := fmt.Sprintf("[%s] Server received: %s\n",
			time.Now().Format(time.RFC3339), message)

		fmt.Fprintf(conn, response)

		// Reset the deadline with each interaction
		conn.SetDeadline(time.Now().Add(5 * time.Minute))
	}

	// Check for scanner errors
	if err := scanner.Err(); err != nil {
		log.Printf("Error reading from client %s: %v", clientAddr, err)
	}

	log.Printf("Client disconnected: %s", clientAddr)
}

func main() {
	// Configuration
	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}

	// Start server
	listener, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatalf("Error starting server: %v", err)
	}
	defer listener.Close()

	keyErr := genServerKeys()
	if keyErr != nil {
		log.Fatalf("Error generating server keys: %v", err)
	}

	log.Printf("Server started on port %s", port)

	// Accept connections in a loop
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Printf("Error accepting connection: %v", err)
			continue
		}

		// Handle each client in a goroutine
		go handleConnection(conn)
	}
}
