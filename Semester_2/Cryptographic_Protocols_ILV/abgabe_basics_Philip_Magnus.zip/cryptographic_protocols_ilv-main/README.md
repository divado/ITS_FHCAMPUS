# Cryptographic Protocols ILV

**Student: Philip Magnus**

This repository contains the code for the basics implementation for Cryptographic Protocols ILV.

The Basics consist of:
1. RSA
2. EC
3. DSA
4. x509.3 
5. HMAC
6. Hashing (SHA512)
7. Symmetric Encryption (AES)


## 1. RSA

To start the RSA client and server implementation simply make use of the included `docker compose` file in the rsa directory.

```bash
$ docker compose build --no-cache
```

The server can then be started in its own container.

```bash
$ docker compose up server
```

In a second shell the client can then be started in a second container.

```bash
$ docker compose run --remove-orphans client
```

Once started the client container will display the following welcome message:

```bash
> Raw message from Server: Welcome to the Go server! Type '/quit' to exit.
Server: Welcome to the Go server! Type '/quit' to exit.
```
The sent message should be reflected back to the client by the server implementation.

To view available commands to setup and start encryption you can use the `/help` command, the output should look similar to this:

```bash
$ /help

Available encryption commands:
/encrpyt - Toggle encryption mode (current: false)
/setup - Setup encryption (generates keys and exchanges these with the server)
/status - Show current encryption status
>
```

Encrypted messages will be decrypted on the server side and re-encrypted by the server with the clients public key. The re-encrypted message will be send back to the client. All this should be readable in the logs.

The client can be quit using the `/quit` command.

## 2. Elliptic Curve

To start the EC client and server implementation simply make use of the included `docker compose` file in the ec directory.

First build the docker images using the following command:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client
```

This will start the client using a set of pre defined standard parameters. The predefined parameters contain a set of predefined curve-, point- and scalar-parameters. The predefined curve is the P-256 curve.

Using the following set of command line arguments these parameters can be set to use random values as well as a user defined point:

```bash
Usage: ec-client [options]
Options:
  -custom-point
        Use a user defined point
  -help
        display help message
  -random-curve
        Use random curve parameters
  -random-point
        Use a random point on the curve
  -random-scalar
        Use Random Scalar
  -scalar string
        Use a specified scalar (if -random is not set) (default "811935")
  -server string
        Address of EC-server (Host:Port)
```
The `-random` argument, generating a random scalar value, can not be combined with the `-random-curve` argument. The generated curve parameters come without the order of the curve and thus a correct scalar value can not be calculated. The prime modulo value for a generated curve has a length of 256-Bit, the a and b coefficients are random values chosen between 0 and 100 to make calculations easier.

The corresponding EC-server address can be set with the `-server` argument but is not needed when using the docker setup.

With the `-scalar` option a userdefined scalar can be set. The `-random-scalar` argument will generate a random scalar value.

## 3. DSA

To build the DSA docker containers use the following command:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client <Message>
```

The client will fetch the puclic DSA key of the server. Next the given message will be send to the server and signed using DSA. The server will send the signed message back to the client, which will in turn validate the signature with the servers public key.

An example output may look like this:

```bash
Received public key from server.
Server public key P: 716793418946896673040802352524...
Server public key Q: 1165487852295925807488444389871428457430346330963
Sending message 'Message' to server for signature...
Received signature from server.
Signature: R=549136950049238951766434516508610883131172839632, S=397880048890039909945570373040942878993791271892
=== Verify details ===
Message: Message
Signature R: 549136950049238951766434516508610883131172839632
Signature S: 397880048890039909945570373040942878993791271892
Public Key Y: 330201026473920235924617111789...
Hash z: 399053064406658193677232507443804987391324109975
w: 302883933329853681905169941345245405205378735365
u1: 104577149971860503304678873929040046176539905513
u2: 462880705050287862740749278753125555169602117784
v1 (g^u1 mod p): 598876579167131450078324263539...
v2 (y^u2 mod p): 457627984617407543013973415235...
v (mod p): 188649239719236310332256455639...
v (mod q): 549136950049238951766434516508610883131172839632
r (for comparison): 549136950049238951766434516508610883131172839632
VALID: v = r
The signature was succesfully verified locally! ✓
```

## 4. x509.3 

The server in this example initializes an HTTP server that listens for requests from the client. Upon receiving a request, it generates a new x509 certificate and sends it back to the client. The client then reads the certificate and checks its validity.

First build the docker setup using:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client
```

This implementation uses the exisiting GO libraries for x509 available under `crypto/x509`.

## 5. HMAC


The server listens for tcp connections from clients. The connected client sends a message with a HMAC calculated based of a predefined secret. The server reads the message and checks the HMAC for its validity and responds to the client with the result of the validity check.

First build the docker setup using:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client
```

This implementation uses the exisiting GO libraries for HMAC available under `crypto/hmac`.

## 6. Hashing

The server listens for HTTP POST messages containing a message in a `json` body:

```json
{
    "Message" : "<Message goes here>"
}
```

The server will calculate the SHA512 hash for the received message and sends a `json` response containing the received message as well as the calculated hash:

```json
{
    "Message" : "<Message goes here>",
    "Hash" : "<Hash goes here>"
}
```

The client will unpack the `json` response and present the received reponse to the user.

First build the docker setup using:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client
```

This implementation uses the exisiting GO libraries for SHA512 available under `crypto/sha512`.

## 7. Symmetric encryption

The server listens for HTTP POST messages containing a message and operation in a `json` body:

```json
{
    "Message" : "<Message goes here>",
    "Operation": "encrpyt || decrypt"
}
```

The server will calculate the SHA512 hash for the received message and sends a `json` response containing the received message, the operation result as well as the operation itself:

```json
{
    "Message" : "<Message goes here>",
    "ResultMessage" : "<Result goes here>",
    "Operation": "encrypt || decrypt"
}
```

The client will unpack the `json` response and present the received reponse to the user.

First build the docker setup using:

```bash
$ docker compose build --no-cache
```

Next start the server using docker compose:

```bash
$ docker compose up server
```

The client can then be started with the following command:

```bash
$ docker compose run --remove-orphans client
```

This implementation uses the exisiting GO libraries for AES available under `crypto/aes`.