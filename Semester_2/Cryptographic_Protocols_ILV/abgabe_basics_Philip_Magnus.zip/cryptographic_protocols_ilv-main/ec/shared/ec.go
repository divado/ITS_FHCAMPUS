package shared

import (
	"errors"
	"math/big"
)

type Point struct {
	X string `json:"x"`
	Y string `json:"y"`
}

type CurveParams struct {
	P string `json:"p"`
	A string `json:"a"`
	B string `json:"b"`
	N string `json:"n"`
}

type ScalarMultRequest struct {
	Curve  CurveParams `json:"curve"`
	Point  Point       `json:"point"`
	Scalar string      `json:"scalar"`
}

type ScalarMultResponse struct {
	Point      Point  `json:"point"`
	IsInfinity bool   `json:"isInfinity"`
	Error      string `json:"error,omitempty"`
}

var (
	ErrInvalidPoint     = errors.New("invalid point")
	ErrPointNotOnCurve  = errors.New("point not on curve")
	ErrInvalidScalar    = errors.New("invalid scalar")
	ErrInvalidParameter = errors.New("invalid curve parameters")
)

func ErrorResponse(err error) ScalarMultResponse {
	return ScalarMultResponse{
		Error: err.Error(),
	}
}

func PointToBigInt(p Point) (*big.Int, *big.Int, error) {
	x, success := new(big.Int).SetString(p.X, 10)
	if !success {
		return nil, nil, ErrInvalidPoint
	}

	y, success := new(big.Int).SetString(p.Y, 10)
	if !success {
		return nil, nil, ErrInvalidPoint
	}

	return x, y, nil
}

func BigIntToPoint(x, y *big.Int) Point {
	return Point{
		X: x.String(),
		Y: y.String(),
	}
}

func CurveParamsToBigInt(params CurveParams) (*big.Int, *big.Int, *big.Int, *big.Int, error) {
	p, success := new(big.Int).SetString(params.P, 10)
	if !success || p.Sign() <= 0 {
		return nil, nil, nil, nil, ErrInvalidParameter
	}

	a, success := new(big.Int).SetString(params.A, 10)
	if !success {
		return nil, nil, nil, nil, ErrInvalidParameter
	}

	b, success := new(big.Int).SetString(params.B, 10)
	if !success {
		return nil, nil, nil, nil, ErrInvalidParameter
	}

	var n *big.Int
	if params.N != "" {
		n, success = new(big.Int).SetString(params.N, 10)
		if !success {
			return nil, nil, nil, nil, ErrInvalidParameter
		}
	}

	return p, a, b, n, nil
}

func IsOnCurve(x, y, a, b, p *big.Int) bool {
	ySq := new(big.Int).Mul(y, y)
	ySq.Mod(ySq, p)

	xCube := new(big.Int).Exp(x, big.NewInt(3), p)

	ax := new(big.Int).Mul(a, x)
	ax.Mod(ax, p)

	rhs := new(big.Int).Add(xCube, ax)
	rhs.Add(rhs, b)
	rhs.Mod(rhs, p)

	return ySq.Cmp(rhs) == 0
}
