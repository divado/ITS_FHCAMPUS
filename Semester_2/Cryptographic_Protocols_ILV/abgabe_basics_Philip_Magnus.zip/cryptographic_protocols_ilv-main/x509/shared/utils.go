package shared

import (
	"crypto/x509"
	"fmt"
	"time"
)

func ValidateCertificate(cert *x509.Certificate) string {
	if cert == nil {
		return "Error: certificate is empty. ✗"
	}

	now := time.Now()
	if now.Before(cert.NotBefore) {
		return fmt.Sprintf("Error: certificate not vaild (valid after %v) ✗", cert.NotBefore)
	}
	if now.After(cert.NotAfter) {
		return fmt.Sprintf("Error: certificate not valid (valid until %v) ✗", cert.NotAfter)
	}

	isSelfSigned := cert.Issuer.String() == cert.Subject.String()

	if isSelfSigned {
		if err := cert.CheckSignature(cert.SignatureAlgorithm, cert.RawTBSCertificate, cert.Signature); err != nil {
			return "Error: invalid signature for self-signed certificate. ✗"
		}
		return "Valid (selfsigned certificate) ✓"
	}

	roots := x509.NewCertPool()
	roots.AddCert(cert)

	opts := x509.VerifyOptions{
		Roots: roots,
	}

	if _, err := cert.Verify(opts); err != nil {
		return fmt.Sprintf("Error during validation: %v", err)
	}

	return "Certificate is valid. ✓"
}
