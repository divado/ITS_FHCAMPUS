package main

import (
	"aes/shared"
	"aes/symmetric"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
)

func main() {
	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}

	http.HandleFunc("/crypto", handleCryptoRequest)

	fmt.Printf("AES server listening on port %s...\n", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}

func handleCryptoRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST-requests allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Error reading the request", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	var req shared.Request
	if err := json.Unmarshal(body, &req); err != nil {
		http.Error(w, "Invalid JSON format", http.StatusBadRequest)
		return
	}

	log.Printf("Received request: Operation=%s, Message=%s", req.Operation, req.Message)

	var resultMessage string
	var operationDescription string

	switch req.Operation {
	case shared.Encrypt:
		resultMessage, err = symmetric.EncryptAES(req.Message)
		operationDescription = "encrypted"
		if err != nil {
			http.Error(w, fmt.Sprintf("Encryption error: %v", err), http.StatusInternalServerError)
			return
		}
	case shared.Decrypt:
		resultMessage, err = symmetric.DecryptAES(req.Message)
		operationDescription = "decrypted"
		if err != nil {
			http.Error(w, fmt.Sprintf("Decryption error: %v", err), http.StatusInternalServerError)
			return
		}
	default:
		http.Error(w, "Invalid operation: Needs to be 'encrypt' or 'decrypt'", http.StatusBadRequest)
		return
	}

	response := shared.Response{
		OriginalMessage: req.Message,
		ResultMessage:   resultMessage,
		Operation:       operationDescription,
	}

	responseJSON, err := json.Marshal(response)
	if err != nil {
		http.Error(w, "Error creating response", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(responseJSON)

	log.Printf("Send response: message became %s", operationDescription)
}
