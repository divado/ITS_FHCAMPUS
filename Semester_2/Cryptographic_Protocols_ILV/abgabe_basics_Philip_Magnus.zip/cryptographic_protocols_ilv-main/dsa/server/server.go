package main

import (
	"dsa/dsa"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"math/big"
	"net/http"
	"os"
)

var publicKey *dsa.DSAPublicKey
var privateKey *dsa.DSAPrivateKey

type VerifyRequest struct {
	Message   string `json:"message"`
	Signature struct {
		R string `json:"r"`
		S string `json:"s"`
	} `json:"signature"`
}

type VerifyResponse struct {
	Valid bool `json:"valid"`
}

func verifyHandler(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(w, "Only POST-requests allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		http.Error(w, "Error reading the request", http.StatusBadRequest)
		return
	}

	var request VerifyRequest
	if err := json.Unmarshal(body, &request); err != nil {
		http.Error(w, "Invalid JSON-format", http.StatusBadRequest)
		return
	}

	// Konvertiere Strings zu big.Int
	r := new(big.Int)
	s := new(big.Int)
	r.SetString(request.Signature.R, 10)
	s.SetString(request.Signature.S, 10)

	signature := &dsa.DSASignature{
		R: r,
		S: s,
	}

	valid := dsa.Verify(publicKey, []byte(request.Message), signature)

	resp := VerifyResponse{
		Valid: valid,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

func publicKeyHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Only GET-requests allowed", http.StatusMethodNotAllowed)
		return
	}

	// Konvertiere den öffentlichen Schlüssel zu Strings
	data := struct {
		P string `json:"p"`
		Q string `json:"q"`
		G string `json:"g"`
		Y string `json:"y"`
	}{
		P: publicKey.Params.P.String(),
		Q: publicKey.Params.Q.String(),
		G: publicKey.Params.G.String(),
		Y: publicKey.Y.String(),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

func signHandler(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(w, "Only POST-requests allowed", http.StatusMethodNotAllowed)
		return
	}

	// Lese die Nachricht
	message, err := ioutil.ReadAll(req.Body)
	if err != nil {
		http.Error(w, "Error reading the message", http.StatusBadRequest)
		return
	}

	fmt.Printf("Server received message for signing: %s\n", string(message))

	// Signiere die Nachricht mit dem privaten Schlüssel des Servers
	signature, err := dsa.Sign(privateKey, message)
	if err != nil {
		http.Error(w, "Error during signing", http.StatusInternalServerError)
		return
	}

	fmt.Printf("Server signed message: R=%s, S=%s\n", signature.R.String(), signature.S.String())

	// Sende die Signatur zurück
	response := struct {
		R string `json:"r"`
		S string `json:"s"`
	}{
		R: signature.R.String(),
		S: signature.S.String(),
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func main() {

	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}
	// Generiere DSA-Parameter
	params, err := dsa.GenerateParameters(1024)
	if err != nil {
		log.Fatalf("Error generating parameters: %v", err)
	}

	// Generiere Schlüsselpaar
	privKey, pubKey, err := dsa.GenerateKeyPair(params)
	if err != nil {
		log.Fatalf("Error generating key pair: %v", err)
	}
	privateKey = privKey
	publicKey = pubKey

	fmt.Printf("DSA-Server started with folloeing parameters:\n")
	fmt.Printf("P: %s\n", publicKey.Params.P.String()[:30]+"...")
	fmt.Printf("Q: %s\n", publicKey.Params.Q.String())
	fmt.Printf("G: %s\n", publicKey.Params.G.String()[:30]+"...")
	fmt.Printf("Y (public key): %s\n", publicKey.Y.String()[:30]+"...")
	fmt.Printf("X (private key): %s\n", privateKey.X.String())

	http.HandleFunc("/verify", verifyHandler)
	http.HandleFunc("/publicKey", publicKeyHandler)
	http.HandleFunc("/sign", signHandler)

	fmt.Printf("Server listening on http://localhost:%s\n", port)
	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%s", port), nil))
}
