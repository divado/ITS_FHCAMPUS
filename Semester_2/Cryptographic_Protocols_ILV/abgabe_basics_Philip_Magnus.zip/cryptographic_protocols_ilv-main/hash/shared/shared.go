package shared

type Response struct {
	Message string `json:"message"`
	Hash    string `json:"hash"`
}

type Request struct {
	Message string `json:"message"`
}
