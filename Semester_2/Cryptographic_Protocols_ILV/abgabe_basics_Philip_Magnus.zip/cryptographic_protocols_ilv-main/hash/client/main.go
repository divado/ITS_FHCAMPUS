package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"hash/shared"
	"io"
	"net/http"
	"os"
)

func main() {

	server := "localhost:8080"
	if envServer := os.Getenv("SERVER_ADDR"); envServer != "" {
		server = envServer
	}

	reader := bufio.NewReader(os.Stdin)
	fmt.Print("PLEASE ENTER A MESSAGE > ")
	message, _ := reader.ReadString('\n')

	req := &shared.Request{
		Message: message,
	}

	fmt.Printf("SENDING MESSAGE: %s\n", req.Message)
	jsonData, err := json.Marshal(req)
	if err != nil {
		fmt.Println("Error marshaling JSON:", err)
		return
	}

	resp, err := http.Post(fmt.Sprintf("http://%s/hash", server), "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		fmt.Println("Error posting message:", err)
		return
	}
	defer resp.Body.Close()

	responseBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Error reading response body:", err)
		return
	}

	responseJson := &shared.Response{}
	err = json.Unmarshal(responseBytes, responseJson)
	if err != nil {
		fmt.Println("Failed to parse response JSON:", err)
		return
	}

	fmt.Println("=== RECEIVED RESPONSE ===")
	fmt.Printf("MESSAGE: %s\n", responseJson.Message)
	fmt.Printf("SHA512 HASH: %s\n", responseJson.Hash)
	fmt.Println("=========================")
}
