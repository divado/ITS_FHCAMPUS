package cryptographic

import (
	"errors"
	"math/big"
)

func Encrypt(message []byte, pubKey *RSAPublicKey) ([]byte, error) {
	m := new(big.Int).SetBytes(message)

	if m.Cmp(pubKey.N) >= 0 {
		return nil, errors.New("message too large for key size")
	}

	c := new(big.Int).Exp(m, pubKey.E, pubKey.N)
	return c.Bytes(), nil
}

func Decrypt(ciphertext []byte, privKey *RSAPrivateKey) ([]byte, error) {
	c := new(big.Int).SetBytes(ciphertext)

	if c.Cmp(privKey.N) >= 0 {
		return nil, errors.New("ciphertext too large for key size")
	}

	m := new(big.Int).Exp(c, privKey.D, privKey.N)
	return m.Bytes(), nil
}
