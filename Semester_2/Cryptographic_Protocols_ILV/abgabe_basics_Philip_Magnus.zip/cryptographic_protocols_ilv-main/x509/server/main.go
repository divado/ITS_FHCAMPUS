package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"x509App/server/cert"
)

func main() {
	port := "8080"
	if envPort := os.Getenv("SERVER_PORT"); envPort != "" {
		port = envPort
	}

	http.HandleFunc("/certificate", func(w http.ResponseWriter, r *http.Request) {
		certPEM, err := cert.GenerateCertificate()
		if err != nil {
			http.Error(w, "Failed to generate certificate", http.StatusInternalServerError)
			return
		}
		log.Printf("Succesfully generated certificate:\n %s\n", certPEM)

		w.Header().Set("Content-Type", "application/x-pem-file")
		w.Write(certPEM)
	})

	fmt.Println("Server is listening on port 8080...")
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}
