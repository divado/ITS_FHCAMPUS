package dsa

import (
	"crypto/rand"
	"crypto/sha256"
	"fmt"
	"math/big"
)

type DSAParams struct {
	P *big.Int
	Q *big.Int
	G *big.Int
}

type DSAPrivateKey struct {
	Params DSAParams
	X      *big.Int
}

type DSAPublicKey struct {
	Params DSAParams
	Y      *big.Int
}

type DSASignature struct {
	R *big.Int
	S *big.Int
}

func GenerateParameters(bits int) (*DSAParams, error) {
	if bits < 512 || bits%64 != 0 {
		return nil, fmt.Errorf("Bit length must be at least 512 and a multiple of 64")
	}

	fmt.Println("=== Generated parameters ===")
	fmt.Printf("Bit length for p: %d\n", bits)

	qBits := 160
	fmt.Printf("Bit length for q: %d\n", qBits)
	var q *big.Int
	var err error

	for {
		q, err = rand.Prime(rand.Reader, qBits)
		if err != nil {
			return nil, fmt.Errorf("Error generating parameter q: %v", err)
		}

		if q.BitLen() == qBits {
			break
		}
	}
	fmt.Printf("Generated q: %s\n", q.String())

	one := big.NewInt(1)
	pMinusOne := new(big.Int)
	p := new(big.Int)

	jBits := bits - qBits
	fmt.Printf("Searching for a %d-bit number j, such that p = j*q + 1 is prime...\n", jBits)

	j := new(big.Int).Exp(big.NewInt(2), big.NewInt(int64(jBits-1)), nil)

	maxAttempts := 10000
	attempt := 0

	for attempt < maxAttempts {
		attempt++

		j.Add(j, big.NewInt(2))

		pMinusOne.Mul(j, q)
		p.Add(pMinusOne, one)

		if p.ProbablyPrime(1) {
			if p.ProbablyPrime(20) {
				fmt.Printf("p found after %d attempts: %s\n", attempt, p.String()[:30]+"...")
				break
			}
		}
	}

	if attempt >= maxAttempts {
		return nil, fmt.Errorf("Could not find a suitable prime number p after %d attempts", maxAttempts)
	}

	h := big.NewInt(2)
	g := new(big.Int)

	pMinusOneOverQ := new(big.Int).Div(pMinusOne, q)

	for {
		g.Exp(h, pMinusOneOverQ, p)

		if g.Cmp(one) != 0 {
			fmt.Printf("Generated g: %s\n", g.String()[:30]+"...")
			break
		}

		h.Add(h, one)
	}

	fmt.Println("Validating parameters...")

	if !p.ProbablyPrime(20) {
		return nil, fmt.Errorf("Generated value p is not prime")
	}

	if !q.ProbablyPrime(20) {
		return nil, fmt.Errorf("Generated value q is not prime")
	}

	rem := new(big.Int).Mod(pMinusOne, q)
	if rem.Cmp(big.NewInt(0)) != 0 {
		return nil, fmt.Errorf("Generated values do not fulfill requrirement p-1 mod q = 0")
	}

	gPowQ := new(big.Int).Exp(g, q, p)
	if gPowQ.Cmp(one) != 0 {
		return nil, fmt.Errorf("Generated value g is not a valid generator")
	}

	fmt.Println("Parameters validated successfully!")

	return &DSAParams{
		P: p,
		Q: q,
		G: g,
	}, nil
}

func GenerateKeyPair(params *DSAParams) (*DSAPrivateKey, *DSAPublicKey, error) {
	x, err := rand.Int(rand.Reader, params.Q)
	if err != nil {
		return nil, nil, err
	}
	if x.Cmp(big.NewInt(0)) == 0 {
		x = big.NewInt(1)
	}

	y := new(big.Int).Exp(params.G, x, params.P)

	privateKey := &DSAPrivateKey{
		Params: *params,
		X:      x,
	}

	publicKey := &DSAPublicKey{
		Params: *params,
		Y:      y,
	}

	fmt.Println("=== Generated keypair ===")
	fmt.Printf("X (private): %s\n", x.String())
	fmt.Printf("Y (public): %s\n", y.String()[:30]+"...")

	return privateKey, publicKey, nil
}

func Sign(privateKey *DSAPrivateKey, message []byte) (*DSASignature, error) {
	hash := sha256.Sum256(message)
	z := new(big.Int).SetBytes(hash[:])
	z.Mod(z, privateKey.Params.Q)

	fmt.Println("=== Sign details ===")
	fmt.Printf("Message: %s\n", string(message))
	fmt.Printf("Hash z: %s\n", z.String())

	var r, s *big.Int
	for {
		k, err := rand.Int(rand.Reader, privateKey.Params.Q)
		if err != nil {
			return nil, err
		}
		if k.Cmp(big.NewInt(0)) == 0 {
			continue
		}
		fmt.Printf("k: %s\n", k.String())

		r = new(big.Int).Exp(privateKey.Params.G, k, privateKey.Params.P)
		r.Mod(r, privateKey.Params.Q)
		fmt.Printf("r: %s\n", r.String())

		if r.Cmp(big.NewInt(0)) == 0 {
			continue
		}

		k_inv := new(big.Int).ModInverse(k, privateKey.Params.Q)
		if k_inv == nil {
			continue
		}
		fmt.Printf("k_inv: %s\n", k_inv.String())

		xr := new(big.Int).Mul(privateKey.X, r)
		z_plus_xr := new(big.Int).Add(z, xr)
		z_plus_xr.Mod(z_plus_xr, privateKey.Params.Q)

		s = new(big.Int).Mul(k_inv, z_plus_xr)
		s.Mod(s, privateKey.Params.Q)
		fmt.Printf("s: %s\n", s.String())

		if s.Cmp(big.NewInt(0)) != 0 {
			break
		}
	}

	return &DSASignature{
		R: r,
		S: s,
	}, nil
}

func Verify(publicKey *DSAPublicKey, message []byte, signature *DSASignature) bool {
	fmt.Println("=== Verify details ===")
	fmt.Printf("Message: %s\n", string(message))
	fmt.Printf("Signature R: %s\n", signature.R.String())
	fmt.Printf("Signature S: %s\n", signature.S.String())
	fmt.Printf("Public Key Y: %s\n", publicKey.Y.String()[:30]+"...")

	if signature.R.Cmp(big.NewInt(0)) <= 0 || signature.R.Cmp(publicKey.Params.Q) >= 0 {
		fmt.Println("Invalid R value")
		return false
	}
	if signature.S.Cmp(big.NewInt(0)) <= 0 || signature.S.Cmp(publicKey.Params.Q) >= 0 {
		fmt.Println("Invalid S value")
		return false
	}

	hash := sha256.Sum256(message)
	z := new(big.Int).SetBytes(hash[:])
	z.Mod(z, publicKey.Params.Q)
	fmt.Printf("Hash z: %s\n", z.String())

	w := new(big.Int).ModInverse(signature.S, publicKey.Params.Q)
	if w == nil {
		fmt.Println("Not able to calculate w")
		return false
	}
	fmt.Printf("w: %s\n", w.String())

	u1 := new(big.Int).Mul(z, w)
	u1.Mod(u1, publicKey.Params.Q)
	fmt.Printf("u1: %s\n", u1.String())

	u2 := new(big.Int).Mul(signature.R, w)
	u2.Mod(u2, publicKey.Params.Q)
	fmt.Printf("u2: %s\n", u2.String())

	v1 := new(big.Int).Exp(publicKey.Params.G, u1, publicKey.Params.P)
	fmt.Printf("v1 (g^u1 mod p): %s\n", v1.String()[:30]+"...")

	v2 := new(big.Int).Exp(publicKey.Y, u2, publicKey.Params.P)
	fmt.Printf("v2 (y^u2 mod p): %s\n", v2.String()[:30]+"...")

	v := new(big.Int).Mul(v1, v2)
	v.Mod(v, publicKey.Params.P)
	fmt.Printf("v (mod p): %s\n", v.String()[:30]+"...")

	v.Mod(v, publicKey.Params.Q)
	fmt.Printf("v (mod q): %s\n", v.String())
	fmt.Printf("r (for comparison): %s\n", signature.R.String())

	isValid := v.Cmp(signature.R) == 0
	if !isValid {
		fmt.Printf("INVALID: v=%s != r=%s\n", v.String(), signature.R.String())
	} else {
		fmt.Println("VALID: v = r")
	}
	return isValid
}
