package main

import (
	"bytes"
	"dsa/dsa"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"os"
)

type SignResponse struct {
	R string `json:"r"`
	S string `json:"s"`
}

type VerifyResponse struct {
	Valid bool `json:"valid"`
}

type PublicKeyResponse struct {
	P string `json:"p"`
	Q string `json:"q"`
	G string `json:"g"`
	Y string `json:"y"`
}

func getServerPublicKey(serverAddr string) (*dsa.DSAPublicKey, error) {
	resp, err := http.Get(fmt.Sprintf("http://%s/publicKey", serverAddr))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("Server responds with status: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var keyResp PublicKeyResponse
	if err := json.Unmarshal(body, &keyResp); err != nil {
		return nil, err
	}

	p := new(big.Int)
	q := new(big.Int)
	g := new(big.Int)
	y := new(big.Int)
	p.SetString(keyResp.P, 10)
	q.SetString(keyResp.Q, 10)
	g.SetString(keyResp.G, 10)
	y.SetString(keyResp.Y, 10)

	return &dsa.DSAPublicKey{
		Params: dsa.DSAParams{
			P: p,
			Q: q,
			G: g,
		},
		Y: y,
	}, nil
}

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: client <Message>")
		os.Exit(1)
	}
	message := os.Args[1]

	serverAddr := "localhost:8080"
	if envAddr := os.Getenv("SERVER_ADDR"); envAddr != "" {
		serverAddr = envAddr
	}

	publicKey, err := getServerPublicKey(serverAddr)
	if err != nil {
		fmt.Printf("Error fetching public key: %v\n", err)
		os.Exit(1)
	}

	fmt.Println("Received public key from server.")
	fmt.Printf("Server public key P: %s\n", publicKey.Params.P.String()[:30]+"...")
	fmt.Printf("Server public key Q: %s\n", publicKey.Params.Q.String())

	fmt.Printf("Sending message '%s' to server for signature...\n", message)
	resp, err := http.Post(fmt.Sprintf("http://%s/sign", serverAddr), "text/plain",
		bytes.NewBuffer([]byte(message)))
	if err != nil {
		fmt.Printf("Error sending request to server: %v\n", err)
		os.Exit(1)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		fmt.Printf("Server responds with status: %d\n", resp.StatusCode)
		body, _ := io.ReadAll(resp.Body)
		fmt.Printf("Response: %s\n", string(body))
		os.Exit(1)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("Error reading response: %v\n", err)
		os.Exit(1)
	}

	var signResp SignResponse
	if err := json.Unmarshal(body, &signResp); err != nil {
		fmt.Printf("Error deserializing response: %v\n", err)
		fmt.Printf("Response: %s\n", string(body))
		os.Exit(1)
	}

	fmt.Println("Received signature from server.")
	fmt.Printf("Signature: R=%s, S=%s\n", signResp.R, signResp.S)

	r := new(big.Int)
	s := new(big.Int)
	r.SetString(signResp.R, 10)
	s.SetString(signResp.S, 10)

	signature := &dsa.DSASignature{
		R: r,
		S: s,
	}

	valid := dsa.Verify(publicKey, []byte(message), signature)

	if valid {
		fmt.Println("The signature was succesfully verified locally! ✓")
	} else {
		fmt.Println("The signature could not be verified locally! ✗")
	}
}
