package symmetric

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"io"
	"os"
)

// The AES key must be 16, 24 or 32 bytes long (for AES-128, AES-192 or AES-256)
var Key = []byte("SuperSecretKey12")

// EncryptAES enctrypts a text with AES in GCM mode
func EncryptAES(plaintext string) (string, error) {

	if envKey := os.Getenv("AES_KEY"); envKey != "" {
		Key = []byte(envKey)
	}

	block, err := aes.NewCipher(Key)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}

	ciphertext := gcm.Seal(nonce, nonce, []byte(plaintext), nil)

	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

// DecryptAES decrypts a text that was encrypted with AES in GCM mode
func DecryptAES(encryptedText string) (string, error) {
	if envKey := os.Getenv("AES_KEY"); envKey != "" {
		Key = []byte(envKey)
	}

	ciphertext, err := base64.StdEncoding.DecodeString(encryptedText)
	if err != nil {
		return "", err
	}

	block, err := aes.NewCipher(Key)
	if err != nil {
		return "", err
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}

	if len(ciphertext) < gcm.NonceSize() {
		return "", errors.New("CIPHERTEXT TO SHORT TO CONTAIN FULL NONCE")
	}

	nonce, ciphertext := ciphertext[:gcm.NonceSize()], ciphertext[gcm.NonceSize():]

	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}

	return string(plaintext), nil
}
